KORSAN DÜNYASI — PROTOTİP 0.1

Bu, özgün korsan temalı, mobil tarayıcıda çalışan bir 2D oyun prototipidir.

DOSYALAR
- index.html: Oyunun tamamı tek dosyada. Harici kütüphane gerektirmez.

NASIL AÇILIR?
1. ZIP dosyasını iPhone Dosyalar uygulamasına kaydet ve aç.
2. index.html dosyasını Safari'de açmayı dene. Bazı iOS sürümlerinde yerel HTML dosyası açma davranışı değişebilir.
3. Daha güvenilir test ve paylaşım için index.html dosyasını GitHub Pages gibi HTTPS statik site barındırıcısına yükle.

KONTROLLER
- Sol taraftaki sanal joystick: gemiyi hareket ettirir.
- TOP ATEŞİ düğmesi: top atışı yapar; basılı tutarak seri atış yapılabilir.
- Düşman gemilerini batırınca altın kazanılır.
- 5 altın karşılığında gemi gövdesini 20 puan onarabilirsin.

ŞU AN NELER VAR?
- Mobil uyumlu deniz ve gemi çizimleri
- Sanal joystick ve dokunmatik top düğmesi
- Düşman gemilerinin oyuncuyu takip etmesi ve ateş etmesi
- Can, altın, batırılan gemi sayacı
- Basit çarpışma, patlama parçacıkları ve onarım

ÖNEMLİ SINIRLAR
- Bu tek cihazda çalışan bir prototiptir; gerçek çevrim içi çok oyunculu değildir.
- Sunucu, hesap sistemi, kayıtlı ilerleme, gerçekçi ses ve özgün görsel varlıklar henüz eklenmemiştir.
- Oyunun kodu eğitim amaçlı başlangıç sürümüdür. Gerçek bir çevrim içi oyuna dönüştürmek için sunucu ve ağ altyapısı gerekir.
